package app;

import ui.Menu;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.executar();
    }
}